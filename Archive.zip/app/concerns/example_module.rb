module ExampleModule

  # code goes here
  
end