require_relative '../config/environment'

RSpec.configure do |config|
  config.order = 'default'
end
 
